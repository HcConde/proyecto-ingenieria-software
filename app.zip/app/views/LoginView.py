import tkinter as tk
from tkinter import ttk, messagebox

class LoginView(ttk.Frame):
    def __init__(self, parent, app_router, auth_controller, state):
        super().__init__(parent)
        self.router = app_router
        self.auth = auth_controller
        self.state = state

        ttk.Label(self, text="Iniciar Sesión", font=("Segoe UI", 18, "bold")).pack(pady=(20, 10))
  
        form = ttk.Frame(self)
        form.pack(pady=10)

        ttk.Label(form, text="Correo").grid(row=0, column=0, sticky="w")
        self.email = ttk.Entry(form, width=35)
        self.email.grid(row=1, column=0, pady=(0, 10))

        ttk.Label(form, text="Contraseña").grid(row=2, column=0, sticky="w")
        self.password = ttk.Entry(form, width=35, show="*")
        self.password.grid(row=3, column=0, pady=(0, 10))

        ttk.Button(self, text="Entrar", command=self.on_login).pack(pady=8)
        ttk.Button(self, text="Volver", command=lambda: self.router.show("home")).pack()
        ttk.Button(
            self,
            text="¿Olvidaste tu contraseña?",
            command=lambda: self.router.show("forgot_password")
        ).pack(pady=6)


    def on_login(self):
        try:
            target_view = self.auth.do_login(
                self.email.get(),
                self.password.get()
            )
            self.router.show(target_view)

        except Exception as e:
            messagebox.showerror("Error", str(e))

